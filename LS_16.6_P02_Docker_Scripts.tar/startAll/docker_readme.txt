Follow intructions below to deploy below components in docker env's.
1. D2 hotfix(applicable for all solutions)
2. Run post installation script for LSSuite and LSSSV

D2 hotfix(applicable for all solutions)
--------------------------------------------------------------------------------------------------
a) download following hotfixes
	- dtwo-42569.zip   : http://mimage.opentext.com/support/ecm/secure/patches/ecd/oneoffs/d2/dtwo-42569.zip
	- dtwo-42570.zip   : http://mimage.opentext.com/support/ecm/secure/patches/ecd/oneoffs/d2/dtwo-42570.zip
	- dtwo-43119_hf.zip: http://mimage.opentext.com/support/ecm/secure/patches/ecd/oneoffs/d2/dtwo-43119_hf.zip 

b) unzip  hotfixes to get following directories:
	- dtwo-42569 
	- dtwo-42570
	- DTWO-43119

c) Applying fixes in content server(lsd2cs) container:
		login into ls2cs container 
		stop JMS: execute stopMethodServer.sh at /opt/dctm/wildfly11.0.0/server as dmadmin user
		exit from container	

		change directory to dtwo-42570
		Execute below commands from dtwo-42570 directory :
		    docker exec -it lsd2cs sh -c " rm /opt/dctm/wildfly11.0.0/server/DctmServer_MethodServer/deployments/ServerApps.ear/lib/xalan-2.7.2.jar"
		    docker cp xalan-2.7.1.jar  lsd2cs:/opt/dctm/wildfly11.0.0/server/DctmServer_MethodServer/deployments/ServerApps.ear/lib 
		    docker exec -it lsd2cs sh -c " chown dmadmin.dmadmin  /opt/dctm/wildfly11.0.0/server/DctmServer_MethodServer/deployments/ServerApps.ear/lib/xalan-2.7.1.jar"

		Login into lsd2cs container
		start JMS :execute startMethodServer.sh at /opt/dctm/wildfly11.0.0/server as dmadmin user
		exit from container

d) Applying fixes in D2 client container(lsd2client) container:
		login into lsd2client container
		stop tomcat server : execute shutdown.sh at /usr/local/tomcat/bin as root user
		exit from container

		change directory to dtwo-42570 
		Execute below commands from dtwo-42570 directory:
                    docker exec -it lsd2client sh -c " rm /usr/local/tomcat/webapps/D2/WEB-INF/lib/xalan-2.7.2.jar"
		    docker cp xalan-2.7.1.jar   lsd2client:/usr/local/tomcat/webapps/D2/WEB-INF/lib

		change directory to dtwo-42569
		Execute below commands from dtwo-42569 directory:
		    docker cp  D2FS4DCTM-API-16.5.0.jar  lsd2client:/usr/local/tomcat/webapps/D2/WEB-INF/lib
		    docker cp  D2FS4DCTM-WEB-16.5.0.jar lsd2client:/usr/local/tomcat/webapps/D2/WEB-INF/lib
		    docker cp  D2-Web-16.5.0.jar   lsd2client:/usr/local/tomcat/webapps/D2/WEB-INF/lib
		
		change directory to DTWO-43119
		Execute below commands from DTWO-43119 directory
		    docker cp bridge.js lsd2client:/usr/local/tomcat/webapps/D2/applet
		
		login into lsd2client container 
		start tomcat server : execute startup.sh at /usr/local/tomcat/bin as root user
		exit from container

e) Applying fixes in D2 Config container(lsd2config) container:
		login into lsd2config container 
		stop tomcat server : execute shutdown.sh at /usr/local/tomcat/bin as root user
		exit from container

		change directory to dtwo-42570
		Execute below commands from dtwo-42570 directory:
		   docker exec -it lsd2config sh -c " rm /usr/local/tomcat/webapps/D2-Config/WEB-INF/lib/xalan-2.7.2.jar"
		   docker cp xalan-2.7.1.jar   lsd2config:/usr/local/tomcat/webapps/D2-Config/WEB-INF/lib

		change directory to dtwo-42569
		Execute below commands from dtwo-42569 directory:
		    docker cp  D2FS4DCTM-API-16.5.0.jar   lsd2config:/usr/local/tomcat/webapps/D2-Config/WEB-INF/lib
		    docker cp  D2FS4DCTM-WEB-16.5.0.jar    lsd2config:/usr/local/tomcat/webapps/D2-Config/WEB-INF/lib
	            docker cp  D2-Web-16.5.0.jar    lsd2config:/usr/local/tomcat/webapps/D2-Config/WEB-INF/lib		
		
		login into lsd2cs container 
		start tomcat server :execute startup.sh at /usr/local/tomcat/bin as root user
		exit from container	

		
Run post installation script for LSSuite and LSSSV - Running updateSchema.sh for LSSuite and LSSSV
--------------------------------------------------------------------------------------------------
	execute below commands in the shell.
		docker exec -ti lsd2cs bash
		su dmadmin
		cd /opt/ls_install/LSSuite/scripts/scripts
			update addRenditions.api and update below lines of script and save it.
		
			from: addrendition,c,l,jp-regional_1-0-normalize.xslt,xsl_ns
			to: addrendition,c,l,/opt/ls_install/LSSuite/scripts/scripts/jp-regional_1-0-normalize.xslt,xsl_ns
			
			from: addrendition,c,l,stf-2-2-normalize.xslt,xsl_ns
			to: addrendition,c,l,/opt/ls_install/opt/ls_install/LSSuite/scripts/scripts/stf-2-2-normalize.xslt,xsl_ns
			
			from: addrendition,c,l,us-regional-2-3-normalize.xslt,xsl_ns
			to: addrendition,c,l,/opt/ls_install/opt/ls_install/LSSuite/scripts/scripts/us-regional-2-3-normalize.xslt,xsl_ns
		
		sh /opt/ls_install/LSSSV/scripts/updateSchema.sh $DOCBASE_NAME $INSTALL_OWNER $INSTALL_OWNER_PASSWORD
		exit
		exit
