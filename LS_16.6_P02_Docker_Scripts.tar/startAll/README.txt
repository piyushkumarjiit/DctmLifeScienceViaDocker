# IntroductionLS Provides four docker images: LSD2CS(D2 plus pack), LSD2Client, LSD2Config and LSWebapps
As of now LS provides two flavor of images runs on Ubuntu and centOS.
You'll first need to decide whether you want which OS you want the LS to run on.
## List of LS Images (All LS images are build on top of D2 Plus pack images as LS has plus pack dependency).
* lsd2cs (Ubuntu and centOS)
LSD2 Content Server docker image.  It's built on top of the D2CS image with added LS installer files.
* lsd2config (Ubuntu). the Ubuntu images work seamlessly for centOS as well.
LSD2 Config webapp docker image. It's build on top of d2Config image with LS scripts in it to deploy specific LS components to D2Client webapp. this image will have XMLViewer and d2ls webapps also deployed along with D2.
* lsd2client (Ubuntu). the Ubuntu images work seamlessly for centOS as well.
LSD2 Client webapp docker image. It's build on top of d2Client image with LS scripts in it to deploy specific LS components to D2Config webapp.
* lswebapps (Ubuntu). the Ubuntu images work seamlessly for centOS as well.LSWebapps docker image. It's built on plain tomcat image with LS webapps(ControlledPrint) to be deployed on the appserver.
## Other Images that LS uses
* da 
Documentum Administrator docker image.
* xPlore and IndexAgent
Images used for searching functionality.
* xcp-cs-setup 
Image used to setup BPM.

# Image Usage
1. It is mandatory to use BPM with LS.  Please refer to the README.txt under the "bpm" folder and setup the BPM first before continuing.
2. Load the all LS docker images, da, xPlore and IndexAgent docker images from tar file into the docker image repository on the docker host.
	docker load -i <tar file>note, if your docker engine is connected to the repository where all required images are there then you don't have to download the images and load them.
To view the list of loaded images, use command "docker images". 
3. The lsd2_compose.yml file contains "cs-db" service as an example. It will automatically start up and configure a postgres DB server for use based on the postgres:9.4 image from the public docker hub. However you can also set up a database server on your own that Content Server will use. You can use any database server on any platform that Content Server supports. 
4. Set the following environment variables in the shell manually. These variables must be set before starting/restarting the container.
	#app server admin password	export APP_SERVER_ADMIN_PASSWORD=jboss
	#This is install owner password	export INSTALL_OWNER_PASSWORD=password
	#This is root user password	export ROOT_USER_PASSWORD=password
	#Repository password. 	export REPOSITORY_PASSWORD=password	export DOCBASE_PASSWORD=password
	#External Data base Server Admin password	export EXTERNALDB_ADMIN_PASSWORD=password
	#Global Registry password	export BOF_REGISTRY_USER_PASSWORD=password	export GLOBAL_REGISTRY_PASSWORD=password
	#AEK passphrase	export AEK_PASSPHRASE=password	export LOCKBOX_PASSPHRASE=Password@123
	#Documentum Administrator presets preferences user password	export PRESETS_PREFERENCES_USER_PASSWORD=webtop		#LifeSciences ControlledPrint admin user password	export CONTROLLED_PRINT_ADMIN_USER_PASSWORD=password		#LifeSciences Config Import mode	export LSCONFIG_IMPORT_MODE=1		#LifeSciences Application server url	export APPSERVER_URL=http://10.194.45.216:8282		#LifeSciences D2 Application name	export D2APP_NAME=D2		#LifeSciences ControlledPrint app url	export CONTROLLEDPRINT_URL=http://10.194.45.216:8383		#LifeSciences PDF doc info	export PDF_DOC_INFO=Subject	export PDF_DOC_DELIMITER=#		#LifeSciences Submission information - number of submissions	export NUMBEROFSUBMISSIONS=1		#LifeSciences Submission information - file store location	export SUBMISSION_FILESTORE_LOCATION=\\\\10.194.45.256\\eSubmissions	#LifeSciences Submission information - semicolon separated submission locations based on number of submissions 	export SUBMISSION_ALIAS_VALUE=\\\\opt\\eSubmissions	#LifeSciences D2 and D2-Config application URL's to be updated in D2 options	export D2_CONFIG_URL=http://10.194.45.216:8181/D2-Config	export D2_CLIENT_URL=http://10.194.45.216:8282/D2	export XMLVIEWER_URL=http://10.194.45.216:8282/XMLViewer		#LifeSciences solution short name. solution short can be any of these LSSuite,LSQM,LSRD,LSSSV and LSTMF	export LIFESCIENCES_SOLUTION=LSSuite	
5. Update lsd2_compose.yml to fit to customer requirements.

	#Documentum Content Server Image name
	LSD2CS_IMAGE_NAME = lsd2cs:16.4.0000
	#Docbase configuration details
	#Base machine IP
	EXTERNAL_IP = 10.239.240.130
	#External Data base server IP
	EXTERNALDB_IP = 10.239.240.130
	#External Data base Server Admin User
	EXTERNALDB_ADMIN_USER = postgres
	#Docbase ID
	DOCBASE_ID = 45321
	#Docbase name
	DOCBASE_NAME = lsd2repo
	# xPlore
	XPLORE_IMAGE_NAME = xplore_ubuntu:1.6.0000.0835
	INDEX_AGENT_IMAGE_NAME = indexagent_ubuntu:1.6.0000.0835 
	# DA
	DA_IMAGE_NAME = da_centos:16.4.0000.0048 
	#LSD2-Config
	D2CONFIG_IMAGE_NAME = lsd2config:16.4.0000
	D2CONFIG_APPSERVER_PORT = 8181	
	#LSD2 Client
	D2CLIENT_IMAGE_NAME = lsd2client:16.4.0000
	D2CLIENT_APPSERVER_PORT = 8282	
	#LS Webapps		LSWEBAPPS_IMAGE_NAME = lswebapps:16.4.0000
6. Start all the containers using docker compose	6a. If LifeSciecnes solution to be installed is LSSSV or LSRD or LSTMF then comment out lswebapps section from lsd2_compose.yml and then start the YML using below command.
	docker-compose -f lsd2_compose.yml up -d
7. If this is the first time that you have started the lsd2cs container, it will install D2 and then LS. This might take a long time. Once the docker-compose starts the lsd2cs container, you can check for progress using the below command. 
	docker logs lsd2cs
	7a. You can also get a shell from the lsd2cs container by using `docker exec -ti lsd2cs bash` and check D2 logs at  "/opt/dctm_docker/logs/<hostname>.log" inside the container. 	7b. The D2 installation could take a long time. You can periodically check the "/opt/D2-install/D2Install.log" in the container for progress.	7c. Once D2 is installed, LS installation is started automatically but before proceeding for installation it will check for valid PE and D2 installation and proceeds further. LS installation could take long time. you can periodically check the logs under "/opt/ls_install/LSSuite/working/logs/" directory in the container for progress.	7d. there are 2 parts to LS installation and both the installation processes are configured to be automatically installed once after the other in below sequence.		1. install_docker.sh - installs dars, and post installation scripts.		2. LSConfigImport_docker.sh - installs pre config import scripts, config import, post installation scripts.	7f. You can use "docker logs lsd2config", "docker logs lsd2client" and "docker logs lswebapps" to check the webapps status.  Note, all the containers lsd2config, lsd2client and lswebapps are going to wait until the D2 is installed on the CS.  Thus you'll see "Waiting for D2 to start install" while lsd2cs container is starting up. You'll see "Waiting for D2 to be installed and ready" when D2 installer starts.  Once D2 installer finished, it will verify docbroker and method server ports are open, then continue to deploy the webapps.8. If you want to install xplore and indexagent, you'll need to start the xplore and indexagent containers after the D2 is completed installed.  Follow the below steps to install xplore and index agent.	8a. Shut down all the containers		docker-compose -f lsd2_compose.yml down		8b. Uncomment the "xplore" and "indexagent" services section in "lsd2_compose.yml"		8c. Restart all the containers again with the xplore and indexagent services		docker-compose -f lsd2_compose.yml up -d			8d. You can use "docker logs xplore" and "docker logs indexagent" to check xPlore and Index Agent status.  Once the docker-compose finishes starting the xplore and indexagent containers, you can access the below web site		http://<docker host external ip>:9300/dsearchadmin, username is "admin" and password is "password" 		http://<docker host external ip>:9200/IndexAgent, username and password are the repository admin user and password.		All installations only run once when the container starts for the first time.  Any subsequent restart of the containers will simply start the installed services.
You can use "docker logs xplore" and "docker logs indexagent" to check xPlore and Index Agent status.  Once the docker-compose finishes starting the xplore and indexagent containers, you can access the below web site9. Once LS installation is done. you need to manually approve client name starts with CS_PE as privileged client.	steps to be followed to mark CS_PE as a privileged client.	9a. Login to DA and select Administration --> Client Rights Management --> Privileged Clients	9b. Click on Manage Clients and add client which name starts with CS_PE.	9c. Once added, right click on the app with the client name set to CS_PE and approve the same.		10. Once all containers are up and running, LS installation is complete. execute docker_readme.txt from startAll.below url's can be hit to access respective applications.
http://<docker host external ip>:8080/da, username and password are the repository admin user and password.http://<docker host external ip>:8181/D2-Config, username and password are the repository admin user and password.http://<docker host external ip>:8282/D2http://<docker host external ip>:8383/controlledprint