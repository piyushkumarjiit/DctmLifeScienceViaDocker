# Introduction
D2 installer installs D2 jars into the bpm.ear.  Below is the instruction on how to setup BPM in a content server container first before starting the D2 docker containers.1. Download content server 16.4.0110 version docker image from below url:       https://knowledge.opentext.com/knowledge/llisapi.dll?func=ll&objId=74934033&objAction=browse&viewType=1    Download xcp-cs-setup 16.4.0110 docker image from below url 	   https://knowledge.opentext.com/knowledge/llisapi.dll?func=ll&objId=74950978&objAction=browse&viewType=1 	
2. Load the base content server docker image and xcp-cs-setup docker image from tar file into the docker image repository on the docker host. 
	docker load -i <tar file>
To view the list of loaded images, use command "docker images".  
3. The bpm_compose.yml file contains "rcs" service as an example. It will automatically start up and configure a postgres DB server for use based on the postgres:9.4 image from the public docker hub. However you can also set up a database server on your own that Content Server will use. You can use any database server on any platform that Content Server supports. 
4. Set the following environment variables in the shell manually. These variables must be set before starting/restarting the container.
	#app server admin password	export APP_SERVER_PASSWORD=jboss	#This is install owner password	export INSTALL_OWNER_PASSWORD=password	#This is root user password	export ROOT_PASSWORD=password	#Repository password. Required only for stateless configuration 	export DOCBASE_PASSWORD=password	#External Data base Server Admin password	export DATABASE_PASSWORD=password	#Global Registry password	export GLOBAL_REGISTRY_PASSWORD=password	#AEK passphrase	export AEK_PASSPHRASE=password	export LOCKBOX_PASSPHRASE=Password@123
5. Provide execute permissions to file make_tablespace.sh present inside postgress folder.   chmod +x make_tablespace.sh	
6. Modify the bpm_compose.yml to fit the customer's environment.

7. Start all the containers using docker compose	docker-compose -f bpm_compose.yml up -d
8. If this is the first time that you have started the content server container, it will create the docbroker, docbase and install BPM. This might take a long time. Check for progress. 
	docker logs d2cs
You can also get a shell from the content server container by using `docker exec -ti d2cs bash` and check the logs at  "/opt/dctm_docker/logs/<hostname>.log" inside the container. 
You can use "docker logs dctmcs_xcp-cs-setup_1" to check BPM install status.  Note: xcp-cs-setup container is going to wait until the docbase is installed on the CS.  Thus you'll see "Waiting for docbase to be installed and ready" while content server container is still creating docbroker and install docbase.  You'll see "[EAR Installer] Successfully installed bpm.ear
[xCP CS Setup] Finished installing EAR" when the BPM is installed successfully.9. Once BPM is installed successfully. login to Content Server container and restart JMS. you can login to Content server container using below command.	docker exec -ti <container name> bash	a. Restart JMS with installation owner account. you can follow below commands.	su dmadmin --> login with install owner account	cd /opt/dctm/wildfly11.0.0/server	./stopMethodServer.sh		./startMethodServer.sh &
10.  Once everything is installed, you can shutdown the base content server container and xcp-cs-setup container by using
docker-compose -f bpm_compose.yml down
11.  Now you can continue to start all the LSD2 containers.  

