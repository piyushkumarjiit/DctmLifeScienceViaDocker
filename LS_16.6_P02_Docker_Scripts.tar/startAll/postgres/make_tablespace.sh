#!/bin/bash

mkdir -p ${PGDATA}/db_${DOCBASE_NAME}_dat.dat
chown -R ${POSTGRES_USER}:${POSTGRES_USER} ${PGDATA}/db_${DOCBASE_NAME}_dat.dat

